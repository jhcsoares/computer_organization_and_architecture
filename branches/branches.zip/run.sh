#!/bin/bash
cd "$(dirname "$0")"

ghdl -a alu.vhd
ghdl -e alu

ghdl -a instruction_register.vhd
ghdl -e instruction_register

ghdl -a blt_register.vhd
ghdl -e blt_register

ghdl -a is_negative_register.vhd
ghdl -e is_negative_register

ghdl -a overflow_register.vhd
ghdl -e overflow_register

ghdl -a jump_data_reg.vhd
ghdl -e jump_data_reg

ghdl -a mux4x1.vhd
ghdl -e mux4x1

ghdl -a rom.vhd
ghdl -e rom

ghdl -a pc.vhd
ghdl -e pc

ghdl -a control_unity.vhd
ghdl -e control_unity

# ghdl -a control_unity_tb.vhd
# ghdl -e control_unity_tb

ghdl -a programmable_calculator.vhd
ghdl -e programmable_calculator

ghdl -a programmable_calculator_tb.vhd
ghdl -e programmable_calculator_tb

ghdl -a reg16bits.vhd
ghdl -e reg16bits

ghdl -a registers_bank.vhd
ghdl -e registers_bank


ghdl -a states_machine.vhd
ghdl -e states_machine

ghdl -r programmable_calculator_tb --wave=programmable_calculator_tb.ghw

gtkwave programmable_calculator_tb.gtkw
